Remember to define function called remediationaction

def remediationaction()