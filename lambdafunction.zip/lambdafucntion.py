#Remember to define function called remediationaction
#!/usr/bin/python

import boto3,botocore

quarantine_sg = isolationSg
    
def remediationaction(event,context):
    sts = boto3.client('sts')
    response = sts.get_caller_identity()
    print(response['Arn']) 
    Instance_ID=event['Findings'][0]['Resource']['InstanceId']
    Instance_State=event['Findings'][0]['Resource']['InstanceState']

    print("This is the isnstance ID:",Instance_ID)
    print("This is the instance State:",Instance_State)

    ec2=boto3.client('ec2')
    response = ec2.describe_instances(InstanceIds=[Instance_ID], DryRun=False)
    print(response)
